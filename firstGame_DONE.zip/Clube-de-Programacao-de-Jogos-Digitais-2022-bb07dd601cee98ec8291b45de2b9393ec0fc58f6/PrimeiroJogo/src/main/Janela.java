package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
	
	//CLASSE JANELA EXTENDE JFRAME 
public class Janela extends JFrame{
	
	private boolean jogando = true;
	
	//TAXA DE ATUALIZA��ES POR SEGUNDO
	private int FPS = 20;
	//DURA��O DE CADA ATUALIZA��O (1 SEGUNDO DIVIDIDO PELA TAXA DE FRAMES)
	private int ms = 1000 / FPS;
	
	private int linhaLimite;

	private int LARGURA = 480, ALTURA = 640;
	private JPanel tela;
	private Elemento player, player2;
	
	private Elemento inimigos[];
	private int inimigosQTD = 7, inimigosSPC =15;
	
	private Elemento tiro, tiro2;

	public Janela() {
		
		this.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				Util.setaTecla(e.getKeyCode(), false);
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				Util.setaTecla(e.getKeyCode(), true);
			}
		});

		player = new Elemento(0, 0, 50, 50, 5);
		player2 = new Elemento(430, 590, 50, 50, 5);
		
		//GERA INIMIGOS CONFORME A QTD ESCOLHIDA, COM UM ESPA�AMENTO ENTRE CADA
		inimigos = new Elemento[inimigosQTD];
		for (int i = 0; i < inimigos.length; i++) {
			int espaco = i * 50 + inimigosSPC * (i+1);
			inimigos[i] = new Elemento(espaco, 0, 50, 50, 1);
		}
		
		tiro = new Elemento(0, 0, 1, 0, 0);
		tiro2 = new Elemento(0,0, 1,0,0);
		
		tela = new JPanel() {
		
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g) {
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, tela.getWidth(), tela.getHeight());
				
				g.setColor(Color.YELLOW);
				g.fillRect(tiro.getPx(), tiro.getPy(), tiro.getLargura(), tela.getHeight());
				g.fillRect(tiro2.getPx(), tiro2.getPy(), tiro2.getLargura(), tela.getHeight());

				g.setColor(Color.GREEN);
				g.fillRect(player.getPx(), player.getPy(), player.getLargura(), player.getAltura());
				g.fillRect(player2.getPx(), player2.getPy(), player2.getLargura(), player2.getAltura());

				g.setColor(Color.BLUE);
				g.fillRect(tela.getWidth()/2, tela.getHeight()-200, 4, 200);
				//PINTA CADA INIMIGO NA COR VERMELHA
				g.setColor(Color.RED);
				for (Elemento inimigo : inimigos) {
					g.fillRect(inimigo.getPx(), inimigo.getPy(), inimigo.getLargura(), inimigo.getAltura());
				}
			}

		};
		

		getContentPane().add(tela);
		
		//M�TODOS DE JFRAME, DEFINE TAMANHO DA JANELA E REDIMENSIONAMENTO
		setSize(LARGURA, ALTURA);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		player.setPx(tela.getWidth() / 2 - player.getLargura() / 2);
		player.setPy(tela.getHeight() - player.getAltura()); 
		player2.setPx(tela.getWidth() - player2.getLargura());
		player2.setPy(tela.getHeight() - player2.getAltura()); 
		
		linhaLimite = tela.getHeight() - 50;

	}
	
	//METODO PARA ATUALIZAR A TELA E REALIZAR A ANIMA��O
	public void inicia() {
		//VARI�VEL LONG PARA CONTROLAR A PR�XIMA(PRX) ATUALIZA��O(ATT)
		long prxAtt = 0;
		
		while (jogando) {
			
			//SE O TEMPO DE SISTEMA ULTRAPASSAR prxAtt, REALIZA-SE A ATUALIZA��O DA TELA
			if (System.currentTimeMillis() >= prxAtt) {
				atualiza();
				tela.repaint();
				//DEFINE A PR�XIMA ATUALIZA��O PARA O TEMPO ATUAL + O TEMPO DE ATUALIZA��O
				prxAtt = System.currentTimeMillis() + ms;
			}
		}
	}
	
	//M�TODO SEPARADO QUE IR� REALIZAR AS ATUALIZA��ES DO JOGO
	public void atualiza() {
		if (Util.right) 
			player.incPx(player.getVelocidade());
		if (Util.left)
			player.incPx(player.getVelocidade()*-1);
		if (Util.a)
			player2.incPx(player2.getVelocidade()*-1);
		if (Util.d) 
			player2.incPx(player2.getVelocidade());

		//SE PLAYER ULTRAPASSAR A BORDA DA TELA, RETORNA NO OUTRO LADO
		if (player.getPx() > (tela.getWidth()/2)-player.getAltura())
			player.setPx(tela.getWidth()/2-player.getLargura()-240);
		if (player.getPx() < 0)  
			player.setPx(0);
		if (player2.getPx() < tela.getWidth()/2)
			player2.setPx(tela.getWidth()-player2.getLargura());
		if (player2.getPx() > tela.getWidth()-player2.getLargura())
			player2.setPx(tela.getWidth()-player2.getLargura());
		
		tiro.setPx(player.getPx() + player.getLargura() / 2);
		tiro2.setPx(player2.getPx() + player2.getLargura() / 2);
		
		for (Elemento inimigo : inimigos) {

			//SE INIMIGO ENCOSTAR NA LINHA LIMITE O JOGO � ENCERRADO
			if (inimigo.getPy() > linhaLimite - inimigo.getAltura()) {
				jogando = false;
				break;
			}

			//SE INIMIGO COLIDIR COM O TIRO E N�O ESTIVER NA BORDA DA TELA, � EMPURRADO PARA TR�S
			if (Util.colide(inimigo, tiro) && inimigo.getPy() > 0) {
				inimigo.incPy(inimigo.getVelocidade() *-2);
				tiro.setPy(inimigo.getPy());
			}
			if (Util.colide(inimigo, tiro2) && inimigo.getPy() > 0) {
				inimigo.incPy(inimigo.getVelocidade() *-2);
				tiro2.setPy(inimigo.getPy());
			}
			else {
				//SE NADA DISSO OCORRER, O INIMIGO VAI EM DIRE��O � LINHA LIMITE
				if (inimigo.equals(inimigos[3])) {
					inimigo.setPy(0);
					inimigo.setAltura(0);
				}
				inimigo.incPy(inimigo.getVelocidade());
			}
		}
	}

	public static void main(String[] args) {
		new Janela().inicia();
		
	}

}
