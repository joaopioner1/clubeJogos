package main;

import java.awt.Color;

public class SkinMinecraft {
	//Joao V. S. Pioner 
	
	//Atributos imutaveis
	// x - y - width - height
	private final int[] hair = {50, 90, 20, 10};//delta x delta y
	private final int[] head = {};
	private final int[] shirt = {}; 
	private final int[] arms = {};
	private final int[] hands = {};
	private final int[] pants = {};
	private final int[] shoes = {};
	
	private Color skinColor; 
	private Color shirtColor;
	private Color pantsColor;
	private Color shoesColor;
	private Color hairColor;
	
	//builders
	public SkinMinecraft(Color skinColor, int x, int y) {
		this.skinColor = skinColor;
		this.hair[x] = 60;
		
	}
	
	public SkinMinecraft(Color skinColor, Color shirtC, Color shoesC, Color pantsC) {
		this.skinColor = skinColor;
		this.shirtColor = shirtC;
		this.shoesColor = shoesC;
		this.pantsColor = pantsC;
	}
	
	public SkinMinecraft(Color skinColor, Color shirtC, Color shoesC, Color pantsC, Color hairColor) {
		this.skinColor = skinColor;
		this.shirtColor = shirtC;
		this.shoesColor = shoesC;
		this.pantsColor = pantsC;
		this.hairColor = hairColor;
	}
	
	//getters
	public int getHair(int index) {
		return hair[index];
	}


	public int getHead(int index) {
		return head[index];
	}


	public int getShirt(int index) {
		return shirt[index];
	}


	public int getArms(int index) {
		return arms[index];
	}


	public int getHands(int index) {
		return hands[index];
	}


	public int getPants(int index) {
		return pants[index];
	}


	public int getShoes(int index) {
		return shoes[index];
	}

	//setters
	public void setSkinColor(Color skinColor) {
		this.skinColor = skinColor;
	}
	
	public void setShirtColor(Color shirtColor) {
		this.shirtColor = shirtColor;
	}

	public void setPantsColor(Color pantsColor) {
		this.pantsColor = pantsColor;
	}

	public void setShoesColor(Color shoesColor) {
		this.shoesColor = shoesColor;
	}

	public void setHairColor(Color hairColor) {
		this.hairColor = hairColor;
	}
	
	
}
